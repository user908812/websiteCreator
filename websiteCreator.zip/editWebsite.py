import random

changes = ''

index = open('index.html', 'a')

styles = ''
field = ''

while True:
    whatToDo = input('''
                    Welcome again!
                    What you want to do? :
                    -------GENERAL--SETTINGS--------
                    Background Color          (bgc)
                    Font Family               (ff) 
                    ------------TOOLS---------------
                    Div                      (d)
                    Text                     (t)
                    Random text              (rt)
                    Image                    (img)
                    Video                    (vid)
                    BreakLine                (br)
                    HorizontalLine           (hr)
                    Button                   (btn)
                    Header (1-6)             (h1-h6)
                    Link                     (a)
                    Unordered List           (ul)
                    Coding text              (code)
                    ----------TEXT--STYLES----------
                    Mark text                (mark)
                    Italic text              (i)
                    Underlined text          (u)
                    Bold text                (b)
                    Small text               (small)
                    Deleted text             (del)
                    ------------ADVANCED------------
                    Expandable text           (et)
                    Figure                    (fig)
                    ------------OPTIONS-------------
                    Save and quit            (q)
                    Quit without saving      (0)
                    --------------------------------\n
                    ''').lower()
    # GENERAL SETTINGS
    if whatToDo == 'bgc':
        yourBGColor = input('Enter a document Background Color: ').lower()
        backgroundColor = '''body {
        background-color: ''' + yourBGColor + '''; 
        }'''
        styles += backgroundColor
        changes += F'+ Background color ({yourBGColor})\n'
        
    elif whatToDo == 'ff':
        yourFont = input('Enter a font name: ')
        font = '''body {
        font-family: ''' + yourFont + ', sans-serif' + '''; 
        }'''
        styles += font
        changes += F'+ Font family ({yourFont}) \n'
# TOOLS
    elif whatToDo == 'd':
            divContent = input('Enter something in div: ')
            div = F'<div>{divContent}</div>'
            field += div
            changes += F'+ Div ({divContent}) \n'

    elif whatToDo == 't':
        typedText = input('Enter text: ')
        textColor = input('Text color: ')
        text = F'<p style="color: {textColor};">{typedText}</p>'
        field += text
        if (textColor == ''):
            textColor = '#000'
        changes += F'+ Text (text:{typedText}, color:{textColor}) \n'

    elif whatToDo == 'rt':
            randomText1 = 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Id voluptatem quaerat delectus velit culpa omnis eaque similique laborum? Totam, dolores?'
            randomText2 = 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Perferendis recusandae quam necessitatibus, libero nobis voluptatibus?'
            randomText3 = 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Sequi voluptatibus praesentium nemo unde, quidem sunt!'
            randomText4 = 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Dicta quis cumque illo alias totam fuga?'
            randomText5 = 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Ducimus facilis earum optio libero laborum, perspiciatis quae.'

            randomTexts = [randomText1, randomText2, randomText3, randomText4, randomText5]
            textIndex = random.randrange(0, 4)

            randomText = F'<div>{randomTexts[textIndex]}</div>'
            field += randomText
            changes += F'+ Random text ({randomTexts[textIndex]})\n'

    elif whatToDo == 'img':
        imageSrc = input('Image source/path: ')
        imageWidth = input('Image width: ')
        imageHeight = input('Image height: ')
        image = F'<img width="{imageWidth}" height="{imageHeight}" src="{imageSrc}" alt="{imageSrc}" title="{imageSrc}" draggable="false">'
        field += image
        changes += F'+ Image (src:{imageSrc}, width:{imageWidth}, height:{imageHeight}) \n'

    elif whatToDo == 'vid':
        videoSrc = input('Video source/path: ')
        videoWidth = input('Video width: ')
        videoHeight = input('Video height: ')
        shouldAutoPlay = input('Should video autoplay? (y/n): ')

        if (shouldAutoPlay == 'y'):
                video = F'<video src="{videoSrc}" width="{videoWidth}" height="{videoHeight}" controls autoplay></video>'
        elif (shouldAutoPlay == 'n'):
                video = F'<video src="{videoSrc}" width="{videoWidth}" height="{videoHeight}" controls></video>'
        else:
                print('Wrong answer! Please try again!')
        field += video
        changes += F'+ Video (src:{videoSrc}, width:{videoWidth}, height:{videoHeight}, shouldAutoPlay:{shouldAutoPlay})\n'

    elif whatToDo == 'br':
        br = '<br>'
        field += br
        changes += F'+ Br\n'

    elif whatToDo == 'hr':
        hr = '<hr>'
        field += hr
        changes += F'+ Hr\n'

    elif whatToDo == 'btn':
        buttonText = input('Button text: ')
        buttonClickEvent = input('Button link: ')
        button = F'<button onclick="window.open(\'{buttonClickEvent}\');">{buttonText}</button>'
        field += button
        changes += F'+ Button (buttonText:{buttonText}, clickEvent:{buttonClickEvent})\n'

    elif whatToDo == 'h1':
        headerOne = input('Enter text: ')
        headerOneText = F'<h1>{headerOne}</h1>'
        field += headerOneText
        changes += F'+ H1 ({headerOne})\n'
    elif whatToDo == 'h2':
        headerTwo = input('Enter text: ')
        headerTwoText = F'<h2>{headerTwo}</h2>'
        field += headerTwoText
        changes += F'+ H2 ({headerTwo})\n'
    elif whatToDo == 'h3':
        headerThree = input('Enter text: ')
        headerThreeText = F'<h3>{headerThree}</h3>'
        field += headerThreeText
        changes += F'+ H3 ({headerThree})\n'
    elif whatToDo == 'h4':
        headerFour = input('Enter text: ')
        headerFourText = F'<h4>{headerFour}</h4>'
        field += headerFourText
        changes += F'+ H4 ({headerFour})\n'
    elif whatToDo == 'h5':
        headerFive = input('Enter text: ')
        headerFiveText = F'<h5>{headerFive}</h5>'
        field += headerFiveText
        changes += F'+ H5 ({headerFive})\n'
    elif whatToDo == 'h6':
        headerSix = input('Enter text: ')
        headerSixText = F'<h6>{headerSix}</h6>'
        field += headerSixText
        changes += F'+ H6 ({headerSix})\n'
    elif whatToDo == 'a':
        linkName = input('Enter a link text (NOT ADDRESS): ')
        linkAddress = input('Enter a link address: ')
        shouldOpenInNewTab = input('Should it open in a new tab? (y/n): ')

        if (shouldOpenInNewTab == 'y'):
            link = F'<a href="{linkAddress}" target="_blank">{linkName}</a>'
        elif (shouldOpenInNewTab == 'n'):
            link = F'<a href="{linkAddress}" target="_self">{linkName}</a>'
        else:
            print('Wrong answer! Please try again!')
        field += link
        changes += F'+ Link (linkName:{linkName}, linkAddress:{linkAddress}, shouldOpenInNewTab:{shouldOpenInNewTab})\n'

    elif whatToDo == 'ul':
        ulListTitle = input('List title/header: ')
        numberOfULChilds = int(input('Enter a number of list items: '))

        listItems = []

        for _ in range(numberOfULChilds):
            content = input('List item content: ')
            listItems.append(F'<li>{content}</li>')

        listItemsHTML = ''.join(listItems)

        unorderedList = F'''
        <h3>{ulListTitle}</h3>
        <ul>
            {listItemsHTML}
        </ul>
        '''
        field += unorderedList
        changes += F'+ Ul\n'

    elif whatToDo == 'code':
        codeContent = input('Enter text: ')
        code = F'<code>{codeContent}</code>'
        field += code
        changes += F'+ Code ({codeContent})\n'

# TEXT STYLES

    elif whatToDo == 'mark':
            markedText = input('Text to mark: ')
            mark = F'<mark>{markedText}</mark>'
            field += mark
            changes += F'+ Marked text ({markedText})\n'

    elif whatToDo == 'i':
            italicText = input('Your italic text: ')
            italic = F'<i>{italicText}</i>'
            field += italic
            changes += F'+ Italic text ({italicText})\n'

    elif whatToDo == 'u':
            underlinedText = input('Your underlined text: ')
            underline = F'<u>{underlinedText}</u>'
            field += underline
            changes += F'+ Underlined text ({underlinedText})\n'

    elif whatToDo == 'b':
            boldText = input('Your bold text: ')
            bold = F'<b>{boldText}</b>'
            field += bold
            changes += F'+ Bold text ({boldText})\n'

    elif whatToDo == 'small':
            smallText = input('Your small text: ')
            small = F'<small>{smallText}</small>'
            field += small
            changes += F'+ Small text ({smallText})\n'

    elif whatToDo == 'del':
            deletedText = input('Your deleted text: ')
            deleted = F'<s>{deletedText}</s>'
            field += deleted
            changes += F'+ Deleted text ({deletedText})\n'

# ADVANCED

    elif whatToDo == 'et':
        topText = input('Enter a first text: ')
        expandabled = input('Enter a second text: ')
        expandableText = F'<aside><details><summary>{topText}</summary><p>{expandabled}</p></details></aside>'
        field += expandableText
        changes += F'+ Expandable text (topText:{topText}, expandabledText:{expandabled})\n'
    elif whatToDo == 'fig':

        imageSrc = input('Image source/path: ')
        imageWidth = input('Image width: ')
        imageHeight = input('Image height: ')
        imageDescription = input('Image description: ')
        image = F'<img width="{imageWidth}" height="{imageHeight}" src="{imageSrc}" alt="{imageSrc}" title="{imageSrc}" draggable="false">'
        figure = F'<figure>{image}<figcaption>{imageDescription}</figcaption></figure>'
        field += figure
        changes += F'+ Figure (imageSrc:{imageSrc}, imageWidth:{imageWidth}, imageHeight:{imageHeight}, imageDesc:{imageDescription})\n'

# OPTIONS

    elif whatToDo == 'q':
        changes += F'--------------------Saved--------------------\n'
        break
    elif whatToDo == '0':
        changes += F'--------------Exit-without-save---------------\n'
        quit()

    with open('index.html', 'a') as index_file:
        index_file.write(F'''
    <style>{styles}</style>
    {field}
            '''
        )

        updateFile = open('update.log', 'w')
        updateFile.write(f'{changes}\n')
        updateFile.close()

index.close()