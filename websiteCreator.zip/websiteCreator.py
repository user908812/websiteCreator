import os
import random

# TODO: framework features
prefix = 'o'

def printSpace():
    print('\n')

print('Welcome to OrzechFramework (HTML and CSS Framework).\n')
print(F'Current path: {os.getcwd()}\n')

readMe = open('README.md', 'w')
readMe.write('''
# Welcome to website creator/framework!
* version 1.3
* b 1.2.0
It's a HTML and CSS framework for beginners to create a simple website.
With this app, you can learn so many things such as:
- html tags and how they work
- you'll find out some shortcuts
- you can learn code faster
and much more. It's like writing a real code!
I hope you will like it. Enjoy :D
''')
readMe.close()

gitIgnore = open('.gitignore', 'w')
gitIgnore.write('''
### Python ###
# Byte-compiled / optimized / DLL files
__pycache__/
*.py[cod]
*$py.class

# C extensions
*.so

# Distribution / packaging
.Python
build/
develop-eggs/
dist/
downloads/
eggs/
.eggs/
lib/
lib64/
parts/
sdist/
var/
wheels/
share/python-wheels/
*.egg-info/
.installed.cfg
*.egg
MANIFEST

# PyInstaller
#  Usually these files are written by a python script from a template
#  before PyInstaller builds the exe, so as to inject date/other infos into it.
*.manifest
*.spec

# Installer logs
pip-log.txt
pip-delete-this-directory.txt

# Unit test / coverage reports
htmlcov/
.tox/
.nox/
.coverage
.coverage.*
.cache
nosetests.xml
coverage.xml
*.cover
*.py,cover
.hypothesis/
.pytest_cache/
cover/

# Translations
*.mo
*.pot

# Django stuff:
*.log
local_settings.py
db.sqlite3
db.sqlite3-journal

# Flask stuff:
instance/
.webassets-cache

# Scrapy stuff:
.scrapy

# Sphinx documentation
docs/_build/

# PyBuilder
.pybuilder/
target/

# Jupyter Notebook
.ipynb_checkpoints

# IPython
profile_default/
ipython_config.py

# pyenv
#   For a library or package, you might want to ignore these files since the code is
#   intended to run in multiple environments; otherwise, check them in:
# .python-version

# pipenv
#   According to pypa/pipenv#598, it is recommended to include Pipfile.lock in version control.
#   However, in case of collaboration, if having platform-specific dependencies or dependencies
#   having no cross-platform support, pipenv may install dependencies that don't work, or not
#   install all needed dependencies.
#Pipfile.lock

# poetry
#   Similar to Pipfile.lock, it is generally recommended to include poetry.lock in version control.
#   This is especially recommended for binary packages to ensure reproducibility, and is more
#   commonly ignored for libraries.
#   https://python-poetry.org/docs/basic-usage/#commit-your-poetrylock-file-to-version-control
#poetry.lock

# pdm
#   Similar to Pipfile.lock, it is generally recommended to include pdm.lock in version control.
#pdm.lock
#   pdm stores project-wide configurations in .pdm.toml, but it is recommended to not include it
#   in version control.
#   https://pdm.fming.dev/#use-with-ide
.pdm.toml

# PEP 582; used by e.g. github.com/David-OConnor/pyflow and github.com/pdm-project/pdm
__pypackages__/

# Celery stuff
celerybeat-schedule
celerybeat.pid

# SageMath parsed files
*.sage.py

# Environments
.env
.venv
env/
venv/
ENV/
env.bak/
venv.bak/

# Spyder project settings
.spyderproject
.spyproject

# Rope project settings
.ropeproject

# mkdocs documentation
/site

# mypy
.mypy_cache/
.dmypy.json
dmypy.json

# Pyre type checker
.pyre/

# pytype static type analyzer
.pytype/

# Cython debug symbols
cython_debug/

# PyCharm
#  JetBrains specific template is maintained in a separate JetBrains.gitignore that can
#  be found at https://github.com/github/gitignore/blob/main/Global/JetBrains.gitignore
#  and can be added to the global gitignore or merged into this file.  For a more nuclear
#  option (not recommended) you can uncomment the following to ignore the entire idea folder.
#.idea/

### Python Patch ###
# Poetry local configuration file - https://python-poetry.org/docs/configuration/#local-configuration
poetry.toml

# ruff
.ruff_cache/

# LSP config files
pyrightconfig.json

# End of https://www.toptal.com/developers/gitignore/api/python
    ''')
gitIgnore.close()

try:
    os.mkdir('src')
    os.mkdir('src/images')
    os.mkdir('src/sounds')
    os.mkdir('src/videos')
except:
    print('Folder(s) already exists! \n')

def indexFunction():
    METAuthor = input('<meta> Website author: ')
    printSpace()

    if METAuthor == '':
        METAuthor = 'AuthorName'

    METAdesc = input('<meta> Website description: ')
    printSpace()

    if METAdesc == '':
        METAdesc = 'description'

    title = input('<title> Website title: ')
    printSpace()
    if (title == ''):
        title = 'Document'
    header = input('<h1> Enter a header: ')
    printSpace()
    description = input('<p> Enter a short website description: ')
    printSpace()

    field = ''
    styles = ''

    while True:
        whatToDo = input('''
                    What you want to do? :
                    -------GENERAL--SETTINGS--------
                    Background Color          (bgc)
                    Font Family               (ff) 
                    ------------TOOLS---------------
                    Div                      (d)
                    Text                     (t)
                    Random text              (rt)
                    Image                    (img)
                    Video                    (vid)
                    BreakLine                (br)
                    HorizontalLine           (hr)
                    Button                   (btn)
                    Header (1-6)             (h1-h6)
                    Link                     (a)
                    Unordered List           (ul)
                    Coding text              (code)
                    ----------TEXT--STYLES----------
                    Mark text                (mark)
                    Italic text              (i)
                    Underlined text          (u)
                    Bold text                (b)
                    Small text               (small)
                    Deleted text             (del)
                    ------------ADVANCED------------
                    Expandable text           (et)
                    Figure                    (fig)
                    ------------OPTIONS-------------
                    Save and quit            (q)
                    Quit without saving      (0)
                    --------------------------------\n
                    ''').lower()
    # GENERAL SETTINGS
        if whatToDo == 'bgc':
            yourBGColor = input('Enter a document Background Color: ').lower()
            backgroundColor = '''body {
            background-color: ''' + yourBGColor + '''; 
            }'''
            styles += backgroundColor
        elif whatToDo == 'ff':
            yourFont = input('Enter a font name: ')
            font = '''body {
            font-family: ''' + yourFont + ', sans-serif' + '''; 
            }'''
            styles += font
    # TOOLS
        elif whatToDo == 'd':
                divContent = input('Enter something in div: ')
                div = F'<div>{divContent}</div>'
                field += div
        elif whatToDo == 't':
            typedText = input('Enter text: ')
            textColor = input('Text color: ')
            text = F'<p style="color: {textColor};">{typedText}</p>'
            field += text
            if (textColor == ''):
                textColor = '#000'

        elif whatToDo == 'rt':
                randomText1 = 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Id voluptatem quaerat delectus velit culpa omnis eaque similique laborum? Totam, dolores?'
                randomText2 = 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Perferendis recusandae quam necessitatibus, libero nobis voluptatibus?'
                randomText3 = 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Sequi voluptatibus praesentium nemo unde, quidem sunt!'
                randomText4 = 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Dicta quis cumque illo alias totam fuga?'
                randomText5 = 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Ducimus facilis earum optio libero laborum, perspiciatis quae.'

                randomTexts = [randomText1, randomText2, randomText3, randomText4, randomText5]
                textIndex = random.randrange(0, 4)

                randomText = F'<div>{randomTexts[textIndex]}</div>'
                field += randomText

        elif whatToDo == 'img':
            imageSrc = input('Image source/path: ')
            imageWidth = input('Image width: ')
            imageHeight = input('Image height: ')
            image = F'<img width="{imageWidth}" height="{imageHeight}" src="{imageSrc}" alt="{imageSrc}" title="{imageSrc}" draggable="false">'
            field += image

        elif whatToDo == 'vid':
            videoSrc = input('Video source/path: ')
            videoWidth = input('Video width: ')
            videoHeight = input('Video height: ')
            shouldAutoPlay = input('Should video autoplay? (y/n): ')

            if (shouldAutoPlay == 'y'):
                 video = F'<video src="{videoSrc}" width="{videoWidth}" height="{videoHeight}" controls autoplay></video>'
            elif (shouldAutoPlay == 'n'):
                 video = F'<video src="{videoSrc}" width="{videoWidth}" height="{videoHeight}" controls></video>'
            else:
                 print('Wrong answer! Please try again!')
            field += video

        elif whatToDo == 'br':
            br = '<br>'
            field += br

        elif whatToDo == 'hr':
            hr = '<hr>'
            field += hr

        elif whatToDo == 'btn':
            buttonText = input('Button text: ')
            buttonClickEvent = input('Button link: ')
            button = F'<button onclick="window.open(\'{buttonClickEvent}\');">{buttonText}</button>'
            field += button

        elif whatToDo == 'h1':
            headerOne = input('Enter text: ')
            headerOneText = F'<h1>{headerOne}</h1>'
            field += headerOneText
        elif whatToDo == 'h2':
            headerTwo = input('Enter text: ')
            headerTwoText = F'<h2>{headerTwo}</h2>'
            field += headerTwoText
        elif whatToDo == 'h3':
            headerThree = input('Enter text: ')
            headerThreeText = F'<h3>{headerThree}</h3>'
            field += headerThreeText
        elif whatToDo == 'h4':
            headerFour = input('Enter text: ')
            headerFourText = F'<h4>{headerFour}</h4>'
            field += headerFourText
        elif whatToDo == 'h5':
            headerFive = input('Enter text: ')
            headerFiveText = F'<h5>{headerFive}</h5>'
            field += headerFiveText
        elif whatToDo == 'h6':
            headerSix = input('Enter text: ')
            headerSixText = F'<h6>{headerSix}</h6>'
            field += headerSixText
        elif whatToDo == 'a':
            linkName = input('Enter a link text (NOT ADDRESS): ')
            linkAddress = input('Enter a link address: ')
            shouldOpenInNewTab = input('Should it open in a new tab? (y/n): ')

            if (shouldOpenInNewTab == 'y'):
                link = F'<a href="{linkAddress}" target="_blank">{linkName}</a>'
            elif (shouldOpenInNewTab == 'n'):
                link = F'<a href="{linkAddress}" target="_self">{linkName}</a>'
            else:
                print('Wrong answer! Please try again!')
            field += link

        elif whatToDo == 'ul':
            ulListTitle = input('List title/header: ')
            numberOfULChilds = int(input('Enter a number of list items: '))

            listItems = []

            for _ in range(numberOfULChilds):
                content = input('List item content: ')
                listItems.append(F'<li>{content}</li>')

            listItemsHTML = ''.join(listItems)

            unorderedList = F'''
            <h3>{ulListTitle}</h3>
            <ul>
                {listItemsHTML}
            </ul>
            '''
            field += unorderedList
        elif whatToDo == 'code':
            codeContent = input('Enter text: ')
            code = F'<code>{codeContent}</code>'
            field += code

    # TEXT STYLES

        elif whatToDo == 'mark':
                markedText = input('Text to mark: ')
                mark = F'<mark>{markedText}</mark>'
                field += mark

        elif whatToDo == 'i':
                italicText = input('Your italic text: ')
                italic = F'<i>{italicText}</i>'
                field += italic

        elif whatToDo == 'u':
                underlinedText = input('Your underlined text: ')
                underline = F'<u>{underlinedText}</u>'
                field += underline

        elif whatToDo == 'b':
                boldText = input('Your bold text: ')
                bold = F'<b>{boldText}</b>'
                field += bold

        elif whatToDo == 'small':
                smallText = input('Your small text: ')
                small = F'<small>{smallText}</small>'
                field += small

        elif whatToDo == 'del':
                deletedText = input('Your deleted text: ')
                deleted = F'<s>{deletedText}</s>'
                field += deleted

    # ADVANCED

        elif whatToDo == 'et':
            topText = input('Enter a first text: ')
            expandabled = input('Enter a second text: ')
            expandableText = F'<aside><details><summary>{topText}</summary><p>{expandabled}</p></details></aside>'
            field += expandableText
        elif whatToDo == 'fig':

            imageSrc = input('Image source/path: ')
            imageWidth = input('Image width: ')
            imageHeight = input('Image height: ')
            imageDescription = input('Image description: ')
            image = F'<img width="{imageWidth}" height="{imageHeight}" src="{imageSrc}" alt="{imageSrc}" title="{imageSrc}" draggable="false">'
            figure = F'<figure>{image}<figcaption>{imageDescription}</figcaption></figure>'
            field += figure

    # OPTIONS

        elif whatToDo == 'q':
            break
        elif whatToDo == '0':
            quit()

    with open('index.html', 'w') as index_file:
        index_file.write(
            F'''<!DOCTYPE html>
            <html lang="pl">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">

                <meta name="author" content="{METAuthor}">
                <meta name="description" content="{METAdesc}">

                <title>{title}</title>
                
                <link rel="icon" href="icon.png">
                <style>
                {styles}
                </style>
            </head>
            <body>
                <h1>{header}</h1>
                <p>{description}</p>
                {field}
                <script src="script.js"></script>
            </body>
            </html>
            '''
        )
def createFile():
    index = open('index.html', 'w')

    indexFunction()
    
    index.close()

createFile()